# OpenWeatherMap API Key
weather_api_key = "3c95031112340047909cf022cbdfac3e"

# Google API Key
g_key = "AIzaSyAyDD6SFzKwWN5bEfh9iyMvdrZhyZTijhk"
